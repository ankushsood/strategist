# Java Mailgun Email Sample for Google App Engine Standard Environment

This sample demonstrates how to use [Mailgun][mailgun-api] on [Google App Engine
standard environment][ae-docs].

See the [sample application documentaion][sample-docs] for more detailed
instructions.

[ae-docs]: https://cloud.google.com/appengine/docs/java/
[mailgun-api]: https://documentation.mailgun.com/
[sample-docs]: https://cloud.google.com/appengine/docs/java/mail/mailgun
