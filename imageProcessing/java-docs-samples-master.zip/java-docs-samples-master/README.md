# java-docs-samples

[![Build Status](https://travis-ci.org/GoogleCloudPlatform/java-docs-samples.svg?branch=master)](https://travis-ci.org/GoogleCloudPlatform/java-docs-samples)
[![ghit.me](https://ghit.me/badge.svg?repo=GoogleCloudPlatform/java-docs-samples)](https://ghit.me/repo/GoogleCloudPlatform/java-docs-samples)
[![Coverage Status](https://codecov.io/gh/GoogleCloudPlatform/java-docs-samples/branch/master/graph/badge.svg)](https://codecov.io/gh/GoogleCloudPlatform/java-docs-samples)

This is a repository that contains java code snippets on [Cloud Platform Documentation](https://cloud.google.com/docs/).

