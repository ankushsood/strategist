# flexible/memcache

How to use memcache on flexible.

# NEEDS WORK

This sample needs to be updated to use redis-memcache
